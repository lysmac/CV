# Laboration 2, Skapa ett digitalt CV

## Uppgiften

Skapa ett interaktivt CV där man presenterar sig själv. Sidan ska vara interaktiv och responsiv, lägre gränsen satt till 360px i bredd.

## Carl Hasselblad CV-sida

[Länk till sidan](https://lysmac.github.io/Labb2/)

Hemsidan består av 4 olika delar:

- Splashscreen
  - Väkomnar besökaren med mitt namn och vad jag gör just nu med css-animerad text. Finns även ikoner för LinkedIn, GitHub samt e-mail-adress. Också en pil som tar en vidare om man inte scrollar självmant.
- Kort om mig
  - En kortare beskrivning av mig och mina intressen. Länkar igen till samma som ovanstående om någon missar. En bild på mig, samt om man hovrar över katterna på kanten av boxen får man se hur dem ser ut.
- Utbildning
  - Lista över alla mina olika utbildningar, genomfördra och den jag läser nu. Kurserna skrivs ut med javascript och läggs automatiskt i de olika kategorierna beroende på var vi är i utbildningen för dagen. Även progressbar genereras så man ser hur långt man kommit i den kurs som är aktiv för tillfället.
- Projekt
  - Några av de få projekt jag har på GitHub hittills. Förhoppningsvis bättre och mer imponerande saker i framtiden.
